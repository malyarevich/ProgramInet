	<footer class="container-fluid text-center navbar-fixed-bottom">
		<div class="container">
			<p>
			</p>
		</div>
	<div class="navbar navbar-default navbar-fixed-bottom">
		<div class="container">
			<p class="navbar-text pull-left">
				© 2020 - Education project for Popivshiy
			</p>
			<a href="#" class="navbar-btn btn-danger btn pull-right">
		<span class="glyphicon glyphicon-user"></span>by Paul Malyarevich</a>
	</div>
		
		
	  </div>
	</footer>
</body>
</html>