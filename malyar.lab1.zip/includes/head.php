<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php if(isset($title)) { echo $title;} else { echo "Site by Malyarevich";}?></title>	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="./assets/bootstrap/3.3.6/css/bootstrap.min.css" />
	
	<!-- Optional theme -->
	<link rel="stylesheet" href="./assets/bootstrap/3.3.6/css/bootstrap-theme.min.css" />

	<!-- jQuery -->
	<script src="./assets/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="./assets/bootstrap/3.3.6/js/bootstrap.min.js" /></script>

	<!-- My CSS -->
	<link rel="stylesheet" type="text/css" href="./assets/css/main.css">

	<!-- My JS -->
	<script type="text/javascript" src="./assets/js/script.js"></script>

</head>
<body>