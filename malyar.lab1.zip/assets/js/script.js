$(document).ready(function(){
	
	$('#country').on('change', function(){
		/*var val = $('#country').val();
		console.log(val);*/	
		if ($('#country').val() == 'flagAnotherCountry'){
			$('#anotherCountry').show(500);
		}
		else {
			$('#anotherCountry').hide(500);
		}
	});

	$('#finishButton').click(function(){
		if($('#firstName').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		if($('#lastName').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		if($('#userName').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		if($('#email').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		if($('#password').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		if($('#repassword').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		if($('#birthDate').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		if($('#country').val() == 'empty') {
			e.preventDefault();
			$(this).addClass('error');
		}
		else if($('#country').val() == 'flagAnotherCountry') {
			if($('#birthDate').val() == '') {
				e.preventDefault();
				$(this).addClass('error');
			}
		}
		if($('#birthDate').val() == '') {
			e.preventDefault();
			$(this).addClass('error');
		}
		$('#firstName').val() == '';
		$('#lastName').val() == '';
		$('#email').val() == '';
		$('#password').val() == '';
		$('#repassword').val() == '';
		$('#firstName').val() == '';
	});
});

